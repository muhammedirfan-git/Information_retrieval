import os
import re
import math
import argparse
import time
from collections import defaultdict

class Fableextractor:
    def __init__(self):
        self.subfolder = 'collection_original'
        self.subfolder1 = 'collection_no_stopwords'
        self.stop_words_file = 'englishsT.txt'

    def extract_collection(self, file_name):
        # Create the subfolder 'collection_original' if it doesn't exist
        os.makedirs(self.subfolder, exist_ok=True)

        # Read the input file
        with open(file_name, 'r') as file:
            content = file.read()

        content = content.split('\n\n\n\n')

        fables = content[2:]
        name_to_fable = {}
        fable_splitter = []
        for i in fables:
            name, fable = i.split("\n\n\n")
            name = f"{fables.index(i)+1:02d}{name.strip().replace(' ','')}"
            name_to_fable[name] = i


        for i in name_to_fable:
            file_name = i

            # Save the fable as a separate file
            with open(os.path.join(self.subfolder, file_name), 'w') as fable_file:
                fable_file.write(name_to_fable[i].strip())

        print("Fable extraction completed successfully.")        
        
    def remove_stop_words(self, text):
         # Create the subfolder 'collection_original' if it doesn't exist
        os.makedirs(self.subfolder1, exist_ok=True)
        # Read the stop words from the file
        with open(self.stop_words_file, 'r') as file:
            stop_words = set(map(str.strip, file.readlines()))

        # Tokenize the text
        words = text.split()

        # Remove the stop words
        words = [word for word in words if word.lower() not in stop_words]

        # Join the remaining words
        cleaned_text = ' '.join(words)

        return cleaned_text

    
    # I read the porter.txt file and found your note.
    def stemming_algorithm(self,word):
        word = word.lower() 
    # Implementation of step 1a
        if re.search(r"sses$", word):
            print (word)
            word = re.sub(r"sses$", "ss", word)
            print (word)
        elif re.search(r"ies$", word):
            word = re.sub(r"ies$", "i", word)
        elif re.search(r"ss$", word):
            word = re.sub(r"ss$", "ss", word)
        elif re.search(r"s$", word):
            word = re.sub(r"s$", "", word)
           
        
    # Implementation of step 1b
        if re.search(r"(.*[aeiouy].*)eed$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*[aeiouy].*)eed$", word).group(1))) > 0:
                word = re.sub(r"eed$", "ee", word)
        elif re.search(r"(.*[aeiouy].*)ed$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*[aeiouy].*)ed$", word).group(1))) > 0:
                word = re.sub(r"ed$", "", word)
                if re.search(r"(.*[aeiouy].*)at$", word):
                    word = re.sub(r"at$", "ate", word)
                elif re.search(r"(.*[aeiouy].*)bl$", word):
                    word = re.sub(r"bl$", "ble", word)
                elif re.search(r"(.*[aeiouy].*)iz$", word):
                    word = re.sub(r"iz$", "ize", word)
                elif re.search(r"(.*[bdglmnprst].*)\1$", word) and not re.search(r"(.*[lsz].*)\1$", word):
                    word = word[:-1]
        elif re.search(r"(.*[aeiouy].*)ing$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*[aeiouy].*)ing$", word).group(1))) > 0:
                word = re.sub(r"ing$", "", word)
                if re.search(r"(.*[aeiouy].*)at$", word):
                    word = re.sub(r"at$", "ate", word)
                elif re.search(r"(.*[aeiouy].*)bl$", word):
                    word = re.sub(r"bl$", "ble", word)
                elif re.search(r"(.*[aeiouy].*)iz$", word):
                    word = re.sub(r"iz$", "ize", word)
                elif re.search(r"(.*[bdglmnprst].*)\1$", word) and not re.search(r"(.*[lsz].*)\1$", word):
                    word = word[:-1]
        
    # Implementation of step 1c
        if re.search(r".*[aeiouy].*y$", word):
            word = re.sub(r"y$", "i", word)   
    # Implementation of step 2   
        if re.search(r"(.*)([aeiouy].*)ational$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ational$", word).group(1))) > 0:
                word = re.sub(r"ational$", "ate", word)
        
        elif re.search(r"(.*)([aeiouy].*)tional$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)tional$", word).group(1))) > 0:
                word = re.sub(r"tional$", "tion", word)
        elif re.search(r"(.*)([aeiouy].*)enci$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)enci$", word).group(1))) > 0:
                word = re.sub(r"enci$", "ence", word)
        elif re.search(r"(.*)([aeiouy].*)anci$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)anci$", word).group(1))) > 0:
                word = re.sub(r"anci$", "ance", word)
        elif re.search(r"(.*)([aeiouy].*)izer$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)izer$", word).group(1))) > 0:
                word = re.sub(r"izer$", "ize", word)
        elif re.search(r"(.*)([aeiouy].*)abli$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)abli$", word).group(1))) > 0:
                word = re.sub(r"abli$", "able", word)
        elif re.search(r"(.*)([aeiouy].*)alli$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)alli$", word).group(1))) > 0:
                word = re.sub(r"alli$", "al", word)
        elif re.search(r"(.*)([aeiouy].*)entli$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)entli$", word).group(1))) > 0:
                word = re.sub(r"entli$", "ent", word)
        elif re.search(r"(.*)([aeiouy].*)eli$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)eli$", word).group(1))) > 0:
                word = re.sub(r"eli$", "e", word)
        elif re.search(r"(.*)([aeiouy].*)ousli$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ousli$", word).group(1))) > 0:
                word = re.sub(r"ousli$", "ous", word)
        elif re.search(r"(.*)([aeiouy].*)ization$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ization$", word).group(1))) > 0:
                word = re.sub(r"ization$", "ize", word)
        elif re.search(r"(.*)([aeiouy].*)ation$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ation$", word).group(1))) > 0:
                word = re.sub(r"ation$", "ate", word)
        elif re.search(r"(.*)([aeiouy].*)ator$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ator$", word).group(1))) > 0:
                word = re.sub(r"ator$", "ate", word)
        elif re.search(r"(.*)([aeiouy].*)alism$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)alism$", word).group(1))) > 0:
                word = re.sub(r"alism$", "al", word)
        elif re.search(r"(.*)([aeiouy].*)iveness$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)iveness$", word).group(1))) > 0:
                word = re.sub(r"iveness$", "ive", word)
        elif re.search(r"(.*)([aeiouy].*)fulness$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)fulness$", word).group(1))) > 0:
                word = re.sub(r"fulness$", "ful", word)
        elif re.search(r"(.*)([aeiouy].*)ousness$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ousness$", word).group(1))) > 0:
                word = re.sub(r"ousness$", "ous", word)
        elif re.search(r"(.*)([aeiouy].*)aliti$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)aliti$", word).group(1))) > 0:
                word = re.sub(r"aliti$", "al", word)
        elif re.search(r"(.*)([aeiouy].*)iviti$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)iviti$", word).group(1))) > 0:
                word = re.sub(r"iviti$", "ive", word)
        elif re.search(r"(.*)([aeiouy].*)biliti$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)biliti$", word).group(1))) > 0:
                word = re.sub(r"biliti$", "ble", word)
        elif re.search(r"(.*)([aeiouy].*)xflurti$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)xflurti$", word).group(1))) > 0:
                word = re.sub(r"xflurti$", "xti", word)

        # Implementation of step 3
        if re.search(r"(.*)([aeiouy].*)ICATE$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ICATE$", word).group(1))) > 0:
                word = re.sub(r"ICATE$", "IC", word)
        elif re.search(r"(.*)([aeiouy].*)ATIVE$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ATIVE$", word).group(1))) > 0:
                word = re.sub(r"ATIVE$", "", word)
        elif re.search(r"(.*)([aeiouy].*)ALIZE$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ALIZE$", word).group(1))) > 0:
                word = re.sub(r"ALIZE$", "AL", word)
        elif re.search(r"(.*)([aeiouy].*)ICITI$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ICITI$", word).group(1))) > 0:
                word = re.sub(r"ICITI$", "IC", word)
        elif re.search(r"(.*)([aeiouy].*)ICAL$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)ICAL$", word).group(1))) > 0:
                word = re.sub(r"ICAL$", "IC", word)
        elif re.search(r"(.*)([aeiouy].*)FUL$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)FUL$", word).group(1))) > 0:
                word = re.sub(r"FUL$", "", word)
        elif re.search(r"(.*)([aeiouy].*)NESS$", word):
            if len(re.findall(r"[aeiouy]", re.search(r"(.*)([aeiouy].*)NESS$", word).group(1))) > 0:
                word = re.sub(r"NESS$", "", word)
         
        # Implementation of step4
        if len(re.findall(r"[aeiouy]", word)) > 1:
            if re.search(r"(.*)([aeiouy].*)al$", word):
                word = re.sub(r"al$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ance$", word):
                word = re.sub(r"ance$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ence$", word):
                word = re.sub(r"ence$", "", word)
            elif re.search(r"(.*)([aeiouy].*)er$", word):
                word = re.sub(r"er$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ic$", word):
                word = re.sub(r"ic$", "", word)
            elif re.search(r"(.*)([aeiouy].*)able$", word):
                word = re.sub(r"able$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ible$", word):
                word = re.sub(r"ible$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ant$", word):
                word = re.sub(r"ant$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ement$", word):
                word = re.sub(r"ement$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ment$", word):
                word = re.sub(r"ment$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ent$", word):
                word = re.sub(r"ent$", "", word)
            elif re.search(r"(.*)([aeiouy].*)([st])ion$", word):
                if re.search(r".*(s|t)ion$", word):
                    word = re.sub(r"(s|t)ion$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ou$", word):
                word = re.sub(r"ou$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ism$", word):
                word = re.sub(r"ism$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ate$", word):
                word = re.sub(r"ate$", "", word)
            elif re.search(r"(.*)([aeiouy].*)iti$", word):
                word = re.sub(r"iti$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ous$", word):
                word = re.sub(r"ous$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ive$", word):
                word = re.sub(r"ive$", "", word)
            elif re.search(r"(.*)([aeiouy].*)ize$", word):
                word = re.sub(r"ize$", "", word)

        # Implementation of Step 5a
        if re.search(r"[aeiou].*e$", word):
            if len(word) > 1:
                word = word[:-1]

        # Implementation of Step 5b
        if re.search(r"[aeiou].*ll$", word):
            if len(word) > 1:
                word=word[:-1]      
        return word            

    def read_ground_truth_file(self,file_path):
        with open(file_path, 'r') as file:
            terms = [term.strip() for term in file.readlines()]
        return set(terms)
    
    def precision_recall_compute(self,query,matching_files,ground_truth_terms,start_time):        
        found_ground_truth_terms = set()
        relevant_documents = set()
        query_ground_truth_terms = [term for term in ground_truth_terms if term.split(" - ")[0].strip().lower() == query.lower()]    
        for term in query_ground_truth_terms:
            term_parts = term.split(" - ")
            term_ids = []
        
            if len(term_parts) > 1:
                term_ids = [int(id.strip()) for id in term_parts[1].split(",") if id.strip().isdigit()]

            found_ground_truth_terms.add(term)
            relevant_documents.update(term_ids)
        # Calculate precision and recall
        num_retrieved = len(matching_files)
        num_relevant = len(relevant_documents)
        matching_document_ids = []
        for file in matching_files:
            match = re.search(r'\d+', file)
            if match:
                document_id = int(match.group())
                matching_document_ids.append(document_id)
        num_retrieved_relevant = len(set(matching_document_ids).intersection(relevant_documents))
        precision = num_retrieved_relevant / num_retrieved if num_retrieved > 0 else 0
        recall = num_retrieved_relevant / num_relevant if num_relevant > 0 else 0

        if query.lower() not in [term.split(" - ")[0].lower() for term in ground_truth_terms]:
            precision = recall = "?"
        
        end_time = time.time()
        elapsed_time = (end_time - start_time) * 1000
        if found_ground_truth_terms:
            print(f"T={elapsed_time:.2f}ms, P={precision}, R={recall}")
        else:
            print(f"T={elapsed_time:.2f}ms, P={precision}, R={recall}")
    
    def build_inverted_index(self, documents):
        inverted_index = defaultdict(list)
        document_lengths = defaultdict(float)
        total_documents = 0

        for file_name in os.listdir(documents):
            with open(os.path.join(documents, file_name), 'r') as file:
                content = file.read()

            words = content.lower().split()
            document_id = file_name.split('.')[0]
            term_frequency = defaultdict(int)

            for word in words:
                inverted_index[word].append((document_id, term_frequency[word]))
                term_frequency[word] += 1
                document_lengths[document_id] += 1

            total_documents += 1

        for term, postings in inverted_index.items():
            df = len(postings)
            idf = math.log(total_documents / df) if df > 0 else 0.0

            for i, (document_id, tf) in enumerate(postings):
                #print(tf*idf)
                #print(math.sqrt(sum(math.pow(tf * idf, 2) for _, tf in postings)))
                if tf * idf != 0.0 and idf != 0.0:
                    tf_idf = (tf * idf) / math.sqrt(sum(math.pow(tf * idf, 2) for _, tf in postings )) if idf != 0.0 else 0.0


                # Store tf-idf value in the inverted index or perform any necessary operations

        return inverted_index, document_lengths

    
    def negation(self, term, inverted_index):
        all_files = set(inverted_index.keys())
        term_files = set(inverted_index.get(term, []))
        return all_files.difference(term_files)
    

    def get_term_documents(self, term, inverted_index):
        return set(inverted_index.get(term, []))
    
    def query_process(self, query, inverted_index, document_lengths):
        query_terms = query.lower().split()

        # Separate terms based on conjunction '&', disjunction '|', and negation '!'
        conjunction_terms = []
        disjunction_terms = []
        negation_terms = []

        for term in query_terms:
            if '&' in term:
                conjunction_terms.extend(term.split('&'))
            elif '|' in term:
                disjunction_terms.extend(term.split('|'))
            elif term.startswith('!'):
                negation_terms.append(term[1:])
            else:
                conjunction_terms.append(term)

        # Initialize query vector
        query_vector = defaultdict(float)

        # Process conjunction terms
        for term in conjunction_terms:
            query_vector[term] += 1

        # Process disjunction terms
        for term in disjunction_terms:
            query_vector[term] += 0.5

        # Process negation terms
        for term in negation_terms:
            query_vector[term] -= 1

        # Calculate query length
        query_length = math.sqrt(sum(math.pow(tf, 2) for tf in query_vector.values()))

        # Calculate scores
        scores = defaultdict(float)

        for term, query_tf in query_vector.items():
            postings = inverted_index.get(term)

            if postings:
                idf = math.log(len(inverted_index) / len(postings))

                for document_id, doc_tf_idf in postings:
                    doc_length = document_lengths[document_id]
                    cosine_similarity = (query_tf / query_length) * (doc_tf_idf / doc_length)
                    scores[document_id] += cosine_similarity

        return scores

    #def query_process(self, query, inverted_index, document_lengths):
        query_vector = defaultdict(float)
        query_terms = query.lower().split()


        # Separate terms based on conjunction '&', disjunction '|', and negation '!'
        conjunction_terms = []
        disjunction_terms = []
        negation_terms = []

        for term in query_terms:
            if '&' in term:
                conjunction_terms.extend(term.split('&'))
            elif '|' in term:
                disjunction_terms.extend(term.split('|'))
            elif term.startswith('!'):
                negation_terms.append(term[1:])
            else:
                conjunction_terms.append(term)

        # Initialize query vector
        query_vector = defaultdict(float)

        # Process conjunction terms
        for term in conjunction_terms:
            query_vector[term] += 1

        # Process disjunction terms
        for term in disjunction_terms:
            query_vector[term] += 0.5

        # Process negation terms
        for term in negation_terms:
            query_vector[term] -= 1

        # Calculate query length
        query_length = math.sqrt(sum(math.pow(tf, 2) for tf in query_vector.values()))


        scores = defaultdict(float)

        # Process each query term
        
        for term in query_terms:
            postings = inverted_index.get(term)
            if postings:
                idf = math.log(len(inverted_index) / len(postings))
                for document_id, doc_tf_idf in postings:
                    doc_length = document_lengths[document_id]
                    cosine_similarity = (query_vector[term] / query_length) * (doc_tf_idf / doc_length)
                    scores[document_id] += cosine_similarity


        return scores




    def inverted_list_search(self, query, documents,ground_truth_terms,start_time):
        inverted_index = self.build_inverted_index(documents)
        result = self.query_process(query, inverted_index)
        matching_files = set()  # Set to store unique file names

        if result:
            print("Matching files found:")
            for file in result:
                matching_files.add(file)

            matching_files = list(matching_files)  # Convert set back to a list
            matching_files.sort()  # Sort the file names alphabetically

            for file in matching_files:
                print(file)
        else:
            print("No matching files found.")

        self.precision_recall_compute(query,matching_files,ground_truth_terms,start_time)    

    def linear_search(self, query, documents,ground_truth_terms,start_time):
        if documents == "original":
            folder = "collection_original"
        elif documents == "no_stopwords":
            folder = "collection_no_stopwords"
        else:
            print("Invalid documents option. Please choose 'original' or 'no_stopwords'.")
            return

        matching_files = []
         # Split query into terms at conjunction operator '&'
        query_terms = query.split('&')  
       
        for file in os.listdir(folder):
            file_path = os.path.join(folder, file)
            with open(file_path, "r") as f:
                content = f.read()

            file_matches = True

            for term in query_terms:
                if '|' in term:
                    subterms = term.split('|')  # Split subterms at disjunction operator '|'
                    subterm_matches = False

                    for subterm in subterms:
                        if subterm.startswith('!'):
                            # Negation operator '!'
                            if subterm[1:].lower() in content.lower():
                                subterm_matches = False
                                break
                        else:
                            if subterm.lower() in content.lower():
                                subterm_matches = True
                                break

                        if not subterm_matches:
                            file_matches = False
                            break

                elif term.startswith('!'):
                    # Negation operator '!'
                    if term[1:].lower() in content.lower():
                        file_matches = False
                        break
                else:
                    if term.lower() not in content.lower():
                            file_matches = False
                            break

            if file_matches:
                matching_files.append(file)

        if matching_files:
            print("Matching files found:")
            for file in matching_files:
                print(file)
        else:
            print("No matching files found.")    

        #compute precision and recall
        self.precision_recall_compute(query,matching_files,ground_truth_terms,start_time)      
        
    def run(self):
        parser = argparse.ArgumentParser()
        parser.add_argument("--extract-collection", metavar="FiLe_NAMe", help="calls document extraction on file")
        parser.add_argument("--query", metavar="QUeRy_TeXT", help="allows to specify a user query")
        parser.add_argument("--model", metavar="MODeL", choices=["bool", "vector"], help="sets the model to Boolean or Vector Space Model")
        parser.add_argument("--search-mode", metavar="seARCH_MODe", choices=["linear","inverted"], help="sets the search to linear mode")
        parser.add_argument("--documents", metavar="DOCUMeNTs", choices=["original", "no_stopwords"], help="specifies the source documents for the search")
        parser.add_argument("--stemming", action='store_true', help='enable stemming')
        args = parser.parse_args()

        ground_truth_file = os.path.join(os.path.dirname(__file__), 'ground_truth.txt')
        ground_truth_terms = self.read_ground_truth_file(ground_truth_file)

        if args.extract_collection:
            self.extract_collection(args.extract_collection)
            # Clean each fable
            for file_name in os.listdir(self.subfolder):
                with open(os.path.join(self.subfolder, file_name), 'r') as file:
                    fable_text = file.read()
                cleaned_text = self.remove_stop_words(fable_text)
                 # save the fable as a separate file
                with open(os.path.join(self.subfolder1, file_name), 'w') as fable_file:
                    fable_file.write(cleaned_text.strip())

        
        if args.query and args.model and args.search_mode and args.documents or args.stemming:
           start_time = time.time()
           if args.stemming: 
               stemmed_query_word = self.stemming_algorithm(args.query)
               print(stemmed_query_word)   
               if args.search_mode == "linear":
                  self.linear_search(stemmed_query_word, args.documents,ground_truth_terms,start_time)
               elif args.search_mode == "inverted":
                    self.inverted_list_search(stemmed_query_word, self.subfolder if args.documents == "original" else self.subfolder1,ground_truth_terms,start_time)
           else:
               if args.search_mode == "linear":
                  self.linear_search(args.query, args.documents,ground_truth_terms,start_time)
               elif args.search_mode == "inverted":
                    self.inverted_list_search(args.query,self.subfolder if args.documents == "original" else self.subfolder1,ground_truth_terms,start_time)               

        if args.model == "vector":
            inverted_index, document_lengths = self.build_inverted_index(
            self.subfolder if args.documents == "original" else self.subfolder1
        )

        if args.query:
            query = args.query.lower()
            scores = self.query_process(query, inverted_index, document_lengths)

            print(f"Query: {query}")
            print("Matching files found:")
            if scores:
                sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
                for document_id, score in sorted_scores:
                    print(f"{document_id}:{score}")
            else:
                print("No matching files found.")

if __name__ == '__main__':
    extractor = Fableextractor()
    extractor.run()